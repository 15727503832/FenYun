import React, { useState, useEffect, useContext } from 'react';
import { UserContext } from '../context/userContext';
import { Table, Button, message, Modal, Form, Input, Space, Select, Popconfirm } from 'antd';
import { getAllUsers, updateUser, toggleUserStatus, resetUserPassword, toggleAdminStatus, toggleClubAdmin } from '../utils/api/users';
import { useNavigate } from 'react-router-dom';
import { SearchOutlined, ExportOutlined } from '@ant-design/icons';

const { Option } = Select;

const ManageUsers = () => {
    const { currentUser } = useContext(UserContext);
    const navigate = useNavigate();
    const [users, setUsers] = useState([]);
    const [filteredUsers, setFilteredUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [editModalVisible, setEditModalVisible] = useState(false);
    const [resetPasswordModalVisible, setResetPasswordModalVisible] = useState(false);
    const [editingUser, setEditingUser] = useState(null);
    const [form] = Form.useForm();
    const [passwordForm] = Form.useForm();
    const [searchForm] = Form.useForm();

    // 检查是否是管理员
    useEffect(() => {
        if (!currentUser?.isAdmin) {
            message.error('您没有权限访问此页面');
            navigate('/');
        }
    }, [currentUser, navigate]);

    // 获取所有用户
    const fetchUsers = async () => {
        setLoading(true);
        try {
            const response = await getAllUsers();
            if (response.code === 200) {
                setUsers(response.data);
                setFilteredUsers(response.data);
            } else {
                message.error(response.msg || '获取用户列表失败');
            }
        } catch (error) {
            message.error('获取用户列表失败');
        }
        setLoading(false);
    };

    useEffect(() => {
        if (currentUser?.isAdmin) {
            fetchUsers();
        }
    }, [currentUser]);

    // 编辑用户
    const handleEdit = (user) => {
        setEditingUser(user);
        form.setFieldsValue({
            username: user.username,
            email: user.email,
        });
        setEditModalVisible(true);
    };

    // 保存编辑
    const handleSave = async (values) => {
        try {
            const response = await updateUser(editingUser._id, values);
            if (response.code === 200) {
                message.success('更新成功');
                setEditModalVisible(false);
                fetchUsers();
            } else {
                message.error(response.msg || '更新失败');
            }
        } catch (error) {
            message.error('更新失败');
        }
    };

    // 切换用户状态
    const handleToggleStatus = async (user) => {
        try {
            const response = await toggleUserStatus(user._id);
            if (response.code === 200) {
                message.success(response.msg);
                fetchUsers();
            } else {
                message.error(response.msg || '操作失败');
            }
        } catch (error) {
            message.error('操作失败');
        }
    };

    // 重置密码
    const handleResetPassword = (user) => {
        setEditingUser(user);
        passwordForm.resetFields();
        setResetPasswordModalVisible(true);
    };

    // 保存新密码
    const handleSavePassword = async (values) => {
        try {
            const response = await resetUserPassword(editingUser._id, values.newPassword);
            if (response.code === 200) {
                message.success('密码重置成功');
                setResetPasswordModalVisible(false);
            } else {
                message.error(response.msg || '密码重置失败');
            }
        } catch (error) {
            message.error('密码重置失败');
        }
    };

    // 切换管理员权限
    const handleToggleAdmin = async (user) => {
        try {
            const response = await toggleAdminStatus(user._id);
            if (response.code === 200) {
                message.success(response.msg);
                fetchUsers();
            } else {
                message.error(response.msg || '操作失败');
            }
        } catch (error) {
            message.error('操作失败');
        }
    };

    // 切换社团管理员权限
    const handleToggleClubAdmin = async (user) => {
        try {
            const response = await toggleClubAdmin(user._id);
            if (response.code === 200) {
                message.success(response.msg);
                fetchUsers();
            } else {
                message.error(response.msg || '操作失败');
            }
        } catch (error) {
            message.error('操作失败');
        }
    };

    // 搜索用户
    const handleFilter = () => {
        const formValues = searchForm.getFieldsValue();
        let result = [...users];

        // 按用户名或邮箱搜索
        if (formValues.search?.trim()) {
            const searchLower = formValues.search.toLowerCase().trim();
            result = result.filter(user => 
                user.username.toLowerCase().includes(searchLower) ||
                user.email.toLowerCase().includes(searchLower)
            );
        }

        // 按状态筛选
        if (formValues.status) {
            result = result.filter(user => 
                formValues.status === 'enabled' ? !user.isDisabled : user.isDisabled
            );
        }

        // 按角色筛选
        if (formValues.role) {
            if (formValues.role === 'admin') {
                result = result.filter(user => user.isAdmin);
            } else if (formValues.role === 'club_admin') {
                result = result.filter(user => !user.isAdmin && user.isClubAdmin);
            } else if (formValues.role === 'user') {
                result = result.filter(user => !user.isAdmin && !user.isClubAdmin);
            }
        }

        setFilteredUsers(result);
    };

    // 重置搜索
    const handleReset = () => {
        searchForm.resetFields();
        setFilteredUsers(users);
    };

    // 导出用户数据
    const handleExport = () => {
        const data = users.map(user => ({
            用户名: user.username,
            邮箱: user.email,
            角色: user.isAdmin ? '管理员' : (user.isClubAdmin ? '社团管理员' : '学生'),
            状态: user.isDisabled ? '已禁用' : '正常',
            创建时间: new Date(user.createdAt).toLocaleString(),
            最后更新: new Date(user.updatedAt).toLocaleString()
        }));

        const headers = ['用户名', '邮箱', '角色', '状态', '创建时间', '最后更新'];
        const csvContent = [
            headers.join(','),
            ...data.map(row => headers.map(header => row[header]).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `用户列表_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
    };

    const columns = [
        {
            title: '用户名',
            dataIndex: 'username',
            key: 'username',
        },
        {
            title: '邮箱',
            dataIndex: 'email',
            key: 'email',
        },
        {
            title: '角色',
            key: 'role',
            render: (_, user) => {
                if (user.isAdmin) return '管理员';
                if (user.isClubAdmin) return '社团管理员';
                return '学生';
            },
        },
        {
            title: '状态',
            dataIndex: 'isDisabled',
            key: 'isDisabled',
            render: (isDisabled) => isDisabled ? '已禁用' : '正常',
        },
        {
            title: '创建时间',
            dataIndex: 'createdAt',
            key: 'createdAt',
            render: (date) => new Date(date).toLocaleString(),
        },
        {
            title: '操作',
            key: 'action',
            render: (_, record) => (
                <Space>
                    <Button type="link" onClick={() => handleEdit(record)} className="cyberpunk-button">
                        编辑
                    </Button>
                    <Popconfirm
                        title={`确定要${record.isDisabled ? '启用' : '禁用'}该用户吗？`}
                        onConfirm={() => handleToggleStatus(record)}
                        disabled={record._id === currentUser._id}
                    >
                        <Button type="link" disabled={record._id === currentUser._id} className="cyberpunk-button danger">
                            {record.isDisabled ? '启用' : '禁用'}
                        </Button>
                    </Popconfirm>
                    <Button type="link" onClick={() => handleResetPassword(record)} className="cyberpunk-button danger">
                        重置密码
                    </Button>
                    <Popconfirm
                        title={`确定要${record.isAdmin ? '取消' : '设置'}管理员权限吗？`}
                        onConfirm={() => handleToggleAdmin(record)}
                        disabled={record._id === currentUser._id}
                    >
                        <Button type="link" disabled={record._id === currentUser._id} className="cyberpunk-button danger">
                            {record.isAdmin ? '取消管理员' : '设置管理员'}
                        </Button>
                    </Popconfirm>
                    {!record.isAdmin && (
                        <Popconfirm
                            title={`确定要${record.isClubAdmin ? '取消' : '设置为'}社团管理员吗？`}
                            onConfirm={() => handleToggleClubAdmin(record)}
                            disabled={record._id === currentUser._id}
                        >
                            <Button type="link" disabled={record._id === currentUser._id} className="cyberpunk-button danger">
                                {record.isClubAdmin ? '取消社团管理员' : '设置为社团管理员'}
                            </Button>
                        </Popconfirm>
                    )}
                </Space>
            ),
        },
    ];

    return (
        <div className="cyberpunk-container">
            <div className="cyberpunk-card">
                <h1 className="cyberpunk-title">用户管理面板</h1>
                
                <div className="cyberpunk-search">
                    <Form
                        form={searchForm}
                        layout="inline"
                        onValuesChange={handleFilter}
                        className="cyberpunk-form"
                    >
                        <div className="cyberpunk-form-inputs">
                            <Form.Item name="search">
                                <Input
                                    prefix={<SearchOutlined />}
                                    placeholder="搜索用户名或邮箱"
                                    className="cyberpunk-input"
                                />
                            </Form.Item>
                            <Form.Item name="status">
                                <Select
                                    placeholder="用户状态"
                                    className="cyberpunk-select"
                                >
                                    <Option value="enabled">正常</Option>
                                    <Option value="disabled">已禁用</Option>
                                </Select>
                            </Form.Item>
                            <Form.Item name="role">
                                <Select
                                    placeholder="用户角色"
                                    className="cyberpunk-select"
                                >
                                    <Option value="admin">管理员</Option>
                                    <Option value="club_admin">社团管理员</Option>
                                    <Option value="user">学生</Option>
                                </Select>
                            </Form.Item>
                        </div>
                        <div className="cyberpunk-form-actions">
                            <Button
                                icon={<SearchOutlined />}
                                onClick={() => form.submit()}
                                className="cyberpunk-button"
                            >
                                搜索
                            </Button>
                            <Button
                                onClick={handleReset}
                                className="cyberpunk-button"
                            >
                                重置
                            </Button>
                            <Button
                                icon={<ExportOutlined />}
                                onClick={handleExport}
                                className="cyberpunk-button success"
                            >
                                导出数据
                            </Button>
                        </div>
                    </Form>
                </div>

                <div className="cyberpunk-table">
                    <Table
                        columns={columns}
                        dataSource={filteredUsers}
                        loading={loading}
                        rowKey="_id"
                        pagination={{
                            pageSize: 10,
                            showTotal: (total) => `共 ${total} 条记录`,
                            showSizeChanger: true,
                            showQuickJumper: true,
                        }}
                    />
                </div>
            </div>

            <Modal
                title="编辑用户信息"
                visible={editModalVisible}
                onCancel={() => setEditModalVisible(false)}
                footer={null}
                className="cyberpunk-modal"
            >
                <Form
                    form={form}
                    onFinish={handleSave}
                    layout="vertical"
                >
                    <Form.Item
                        name="username"
                        label="用户名"
                        rules={[{ required: true, message: '请输入用户名' }]}
                    >
                        <Input className="cyberpunk-input" />
                    </Form.Item>
                    <Form.Item
                        name="email"
                        label="邮箱"
                        rules={[
                            { required: true, message: '请输入邮箱' },
                            { type: 'email', message: '请输入有效的邮箱地址' }
                        ]}
                    >
                        <Input className="cyberpunk-input" />
                    </Form.Item>
                    <Form.Item style={{ marginBottom: 0, textAlign: 'right' }}>
                        <Space>
                            <Button onClick={() => setEditModalVisible(false)} className="cyberpunk-button">
                                取消
                            </Button>
                            <Button type="primary" htmlType="submit" className="cyberpunk-button primary">
                                保存
                            </Button>
                        </Space>
                    </Form.Item>
                </Form>
            </Modal>

            <Modal
                title="重置密码"
                visible={resetPasswordModalVisible}
                onCancel={() => setResetPasswordModalVisible(false)}
                footer={null}
                className="cyberpunk-modal"
            >
                <Form
                    form={passwordForm}
                    onFinish={handleSavePassword}
                    layout="vertical"
                >
                    <Form.Item
                        name="newPassword"
                        label="新密码"
                        rules={[
                            { required: true, message: '请输入新密码' },
                            { min: 6, message: '密码长度不能小于6位' }
                        ]}
                    >
                        <Input.Password className="cyberpunk-input" />
                    </Form.Item>
                    <Form.Item
                        name="confirmPassword"
                        label="确认密码"
                        dependencies={['newPassword']}
                        rules={[
                            { required: true, message: '请确认新密码' },
                            ({ getFieldValue }) => ({
                                validator(_, value) {
                                    if (!value || getFieldValue('newPassword') === value) {
                                        return Promise.resolve();
                                    }
                                    return Promise.reject(new Error('两次输入的密码不一致'));
                                },
                            }),
                        ]}
                    >
                        <Input.Password className="cyberpunk-input" />
                    </Form.Item>
                    <Form.Item style={{ marginBottom: 0, textAlign: 'right' }}>
                        <Space>
                            <Button onClick={() => setResetPasswordModalVisible(false)} className="cyberpunk-button">
                                取消
                            </Button>
                            <Button type="primary" htmlType="submit" className="cyberpunk-button primary">
                                确认重置
                            </Button>
                        </Space>
                    </Form.Item>
                </Form>
            </Modal>

            <style jsx global>{`
                .cyberpunk-container {
                    min-height: 100vh;
                    padding: 2rem;
                    background: linear-gradient(45deg, #000428 0%, #004e92 100%);
                    animation: fadeIn 0.5s ease-in-out;
                    position: relative;
                    overflow: hidden;
                }

                .cyberpunk-card {
                    background: rgba(16, 20, 34, 0.8);
                    border-radius: 20px;
                    box-shadow: 0 8px 32px 0 rgba(0, 194, 255, 0.15);
                    backdrop-filter: blur(8px);
                    border: 1px solid rgba(0, 194, 255, 0.18);
                    padding: 2rem;
                    margin-bottom: 2rem;
                    position: relative;
                    min-height: calc(100vh - 4rem);
                }

                .cyberpunk-title {
                    font-size: 32px;
                    font-weight: 600;
                    color: #00ffff;
                    margin-bottom: 2rem;
                    text-align: center;
                    position: relative;
                    text-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
                    letter-spacing: 2px;
                }

                .cyberpunk-title::after {
                    content: "";
                    position: absolute;
                    bottom: -10px;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 100px;
                    height: 3px;
                    background: linear-gradient(90deg, #00ffff, #0066ff);
                    border-radius: 2px;
                    box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
                }

                .cyberpunk-search {
                    margin-bottom: 2rem;
                    padding: 0;
                    background: transparent;
                    border-radius: 15px;
                }

                .cyberpunk-form {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    gap: 1rem;
                }

                .cyberpunk-form-inputs {
                    display: flex;
                    gap: 1rem;
                    flex: 1;
                }

                .cyberpunk-form-inputs .ant-form-item:first-child {
                    max-width: 200px;
                }

                .cyberpunk-form-actions {
                    display: flex;
                    gap: 1rem;
                    justify-content: flex-end;
                }

                .cyberpunk-input {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border: none !important;
                    border-radius: 4px !important;
                    box-shadow: inset 0 0 10px rgba(0, 194, 255, 0.2) !important;
                    color: #00ffff !important;
                    transition: all 0.3s ease !important;
                }

                .cyberpunk-input input {
                    background: transparent !important;
                    color: #00ffff !important;
                }

                .cyberpunk-input .ant-input {
                    background: transparent !important;
                    color: #00ffff !important;
                }

                .cyberpunk-input .anticon {
                    color: #00ffff !important;
                }

                .cyberpunk-input::placeholder {
                    color: rgba(0, 255, 255, 0.5) !important;
                }

                .ant-input-affix-wrapper:hover,
                .ant-input-affix-wrapper:focus {
                    background: rgba(0, 40, 120, 0.6) !important;
                    border: none !important;
                    box-shadow: inset 0 0 15px rgba(0, 194, 255, 0.3) !important;
                }

                .ant-input-affix-wrapper input.ant-input {
                    background: transparent !important;
                    color: #00ffff !important;
                }

                .ant-input-affix-wrapper .ant-input-prefix {
                    color: #00ffff !important;
                }

                .ant-input-affix-wrapper .ant-input::placeholder {
                    color: rgba(0, 255, 255, 0.5) !important;
                }

                .cyberpunk-button {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border: 1px solid rgba(0, 194, 255, 0.5) !important;
                    color: #00ffff !important;
                    border-radius: 4px !important;
                    padding: 4px 15px !important;
                    height: 32px !important;
                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                    box-shadow: inset 0 0 10px rgba(0, 194, 255, 0.2) !important;
                }

                .cyberpunk-button:hover {
                    background: rgba(0, 40, 120, 0.6) !important;
                    border-color: rgba(0, 194, 255, 0.8) !important;
                    box-shadow: inset 0 0 15px rgba(0, 194, 255, 0.3) !important;
                }

                .cyberpunk-button.primary {
                    background: #1890ff;
                }

                .cyberpunk-button.success {
                    background: rgba(40, 120, 0, 0.4) !important;
                    border-color: rgba(0, 255, 0, 0.5) !important;
                }

                .cyberpunk-button.success:hover {
                    background: rgba(40, 120, 0, 0.6) !important;
                    border-color: rgba(0, 255, 0, 0.8) !important;
                }

                .cyberpunk-button.danger {
                    background: rgba(255, 0, 0, 0.2) !important;
                    border: 1px solid rgba(255, 0, 0, 0.5) !important;
                    color: #ff0000 !important;
                    box-shadow: 0 0 10px rgba(255, 0, 0, 0.3) !important;
                }

                .cyberpunk-button.danger:hover {
                    background: rgba(255, 0, 0, 0.3) !important;
                    box-shadow: 0 0 20px rgba(255, 0, 0, 0.5) !important;
                }

                .cyberpunk-button.danger::before {
                    background: linear-gradient(
                        120deg,
                        transparent,
                        rgba(255, 0, 0, 0.2),
                        transparent
                    );
                }

                .cyberpunk-table {
                    overflow: hidden;
                    border-radius: 15px;
                    background: rgba(16, 20, 34, 0.7);
                    position: static;
                }

                .cyberpunk-table .ant-table {
                    background: transparent !important;
                    color: #fff !important;
                    position: static;
                }

                .cyberpunk-table .ant-table-thead > tr > th {
                    background: rgba(0, 40, 120, 0.4) !important;
                    color: #00ffff !important;
                    font-weight: 600;
                    border-bottom: 2px solid rgba(0, 194, 255, 0.3);
                    position: static;
                }

                .cyberpunk-table .ant-table-tbody > tr {
                    background: transparent !important;
                    position: static;
                }

                .cyberpunk-table .ant-table-tbody > tr > td {
                    background: transparent !important;
                    border-bottom: 1px solid rgba(0, 194, 255, 0.1);
                    color: #fff !important;
                    transition: none;
                    position: static;
                }

                .cyberpunk-table .ant-table-tbody > tr:hover > td {
                    background: rgba(0, 40, 120, 0.4) !important;
                    transform: none;
                }

                .cyberpunk-table .ant-table-tbody > tr.ant-table-row:hover > td {
                    background: rgba(0, 40, 120, 0.4) !important;
                    transform: none;
                }

                /* 修复表格中的按钮布局 */
                .cyberpunk-table .ant-space {
                    display: flex !important;
                    gap: 8px !important;
                    flex-wrap: nowrap !important;
                }

                .cyberpunk-table .ant-btn-link {
                    margin: 0 !important;
                    padding: 4px 8px !important;
                    white-space: nowrap !important;
                    flex-shrink: 0 !important;
                }

                .cyberpunk-table .ant-space-item {
                    margin: 0 !important;
                    padding: 0 !important;
                }

                /* 确保弹出确认框不重叠 */
                .ant-popover {
                    z-index: 1000 !important;
                }

                .ant-popover-buttons {
                    gap: 8px !important;
                }

                /* 修复表格分页样式 */
                .cyberpunk-table .ant-pagination {
                    background: transparent !important;
                }

                .cyberpunk-table .ant-pagination-item,
                .cyberpunk-table .ant-pagination-prev,
                .cyberpunk-table .ant-pagination-next {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border-color: rgba(0, 194, 255, 0.3) !important;
                }

                .cyberpunk-table .ant-pagination-item:hover,
                .cyberpunk-table .ant-pagination-prev:hover .ant-pagination-item-link,
                .cyberpunk-table .ant-pagination-next:hover .ant-pagination-item-link {
                    background: rgba(0, 40, 120, 0.6) !important;
                    border-color: rgba(0, 194, 255, 0.8) !important;
                }

                .cyberpunk-table .ant-pagination-item-active {
                    background: rgba(0, 194, 255, 0.2) !important;
                    border-color: #00ffff !important;
                }

                .cyberpunk-table .ant-pagination-item a,
                .cyberpunk-table .ant-pagination-prev .ant-pagination-item-link,
                .cyberpunk-table .ant-pagination-next .ant-pagination-item-link {
                    color: #00ffff !important;
                }

                .cyberpunk-table .ant-pagination-item-active a {
                    color: #fff !important;
                    text-shadow: 0 0 8px rgba(0, 255, 255, 0.5);
                }

                /* 修复表格空状态样式 */
                .cyberpunk-table .ant-table-placeholder {
                    background: transparent !important;
                }

                .cyberpunk-table .ant-table-placeholder .ant-table-cell {
                    background: transparent !important;
                    border-bottom: none !important;
                }

                .cyberpunk-table .ant-empty-description {
                    color: rgba(0, 255, 255, 0.5) !important;
                }

                /* 修复表格加载状态样式 */
                .cyberpunk-table .ant-table-tbody > tr.ant-table-placeholder:hover > td {
                    background: transparent !important;
                }

                .cyberpunk-table .ant-spin-dot-item {
                    background-color: #00ffff !important;
                }

                .cyberpunk-modal .ant-modal-content {
                    background: rgba(16, 20, 34, 0.95);
                    border-radius: 20px;
                    box-shadow: 0 8px 32px rgba(0, 194, 255, 0.3);
                    border: 1px solid rgba(0, 194, 255, 0.3);
                }

                .cyberpunk-modal .ant-modal-header {
                    background: rgba(0, 24, 88, 0.9);
                    border-radius: 20px 20px 0 0;
                    border-bottom: 1px solid rgba(0, 194, 255, 0.3);
                    padding: 16px 24px;
                }

                .cyberpunk-modal .ant-modal-title {
                    color: #00ffff;
                    font-size: 20px;
                    font-weight: 600;
                    text-shadow: 0 0 10px rgba(0, 255, 255, 0.3);
                }

                .cyberpunk-modal .ant-modal-body {
                    color: #fff;
                }

                .cyberpunk-modal .ant-form-item-label > label {
                    color: #00ffff;
                }

                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }

                @keyframes pulse {
                    0% { box-shadow: 0 0 10px rgba(0, 194, 255, 0.3); }
                    50% { box-shadow: 0 0 20px rgba(0, 194, 255, 0.5); }
                    100% { box-shadow: 0 0 10px rgba(0, 194, 255, 0.3); }
                }

                .cyberpunk-table .ant-pagination-item {
                    background: rgba(0, 24, 88, 0.9);
                    border-color: rgba(0, 194, 255, 0.3);
                }

                .cyberpunk-table .ant-pagination-item a {
                    color: #00ffff;
                }

                .cyberpunk-table .ant-pagination-item-active {
                    border-color: #00ffff;
                    animation: pulse 2s infinite;
                }

                .cyberpunk-modal .ant-modal-close {
                    color: #00ffff;
                }

                .cyberpunk-modal .ant-modal-close:hover {
                    color: #fff;
                }

                .cyberpunk-card::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-image: 
                        linear-gradient(rgba(0, 194, 255, 0.1) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(0, 194, 255, 0.1) 1px, transparent 1px);
                    background-size: 20px 20px;
                    pointer-events: none;
                    z-index: -1;
                }

                .cyberpunk-title::before {
                    content: attr(data-text);
                    position: absolute;
                    left: -2px;
                    text-shadow: 2px 0 #ff00ff;
                    top: 0;
                    color: #00ffff;
                    overflow: hidden;
                    clip: rect(0, 900px, 0, 0);
                    animation: glitch 2s infinite linear alternate-reverse;
                }

                @keyframes glitch {
                    0% { clip: rect(44px, 9999px, 56px, 0); }
                    20% { clip: rect(12px, 9999px, 65px, 0); }
                    40% { clip: rect(78px, 9999px, 92px, 0); }
                    60% { clip: rect(34px, 9999px, 45px, 0); }
                    80% { clip: rect(89px, 9999px, 98px, 0); }
                    100% { clip: rect(67px, 9999px, 71px, 0); }
                }

                .cyberpunk-select .ant-select-selector {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border: 1px solid rgba(0, 194, 255, 0.5) !important;
                    color: #00ffff !important;
                    border-radius: 4px !important;
                    transition: all 0.3s ease !important;
                }

                .cyberpunk-select .ant-select-arrow {
                    color: #00ffff !important;
                }

                .cyberpunk-select .ant-select-selection-item {
                    color: #00ffff !important;
                }

                .cyberpunk-select .ant-select-dropdown {
                    background: rgba(16, 20, 34, 0.95) !important;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(0, 194, 255, 0.3);
                }

                .cyberpunk-select .ant-select-item {
                    color: #00ffff !important;
                    transition: all 0.3s ease;
                }

                .cyberpunk-select .ant-select-item:hover {
                    background: rgba(0, 194, 255, 0.1) !important;
                }

                .cyberpunk-select .ant-select-item-option-selected {
                    background: rgba(0, 194, 255, 0.2) !important;
                    color: #00ffff !important;
                }

                .cyberpunk-select .ant-select-item-option-active {
                    background: rgba(0, 194, 255, 0.1) !important;
                }

                .cyberpunk-select .ant-select-selection-placeholder {
                    color: rgba(0, 255, 255, 0.5) !important;
                }

                /* 确认弹窗样式 */
                .ant-popconfirm .ant-popover-content {
                    background: rgba(16, 20, 34, 0.95) !important;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(0, 194, 255, 0.3);
                    border-radius: 8px;
                }

                .ant-popconfirm .ant-popover-inner {
                    background: transparent !important;
                }

                .ant-popconfirm .ant-popover-inner-content {
                    color: #00ffff !important;
                }

                .ant-popconfirm .ant-popover-message {
                    color: #fff !important;
                }

                .ant-popconfirm .ant-popover-message .anticon-exclamation-circle {
                    color: #ff4d4f !important;
                    font-size: 16px !important;
                }

                .ant-popconfirm .ant-popover-buttons {
                    display: flex;
                    gap: 8px;
                }

                .ant-popconfirm .ant-btn {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border: 1px solid rgba(0, 194, 255, 0.5) !important;
                    color: #00ffff !important;
                }

                .ant-popconfirm .ant-btn-primary {
                    background: rgba(0, 40, 120, 0.6) !important;
                }

                .ant-popconfirm .ant-btn:hover {
                    background: rgba(0, 40, 120, 0.6) !important;
                    border-color: rgba(0, 194, 255, 0.8) !important;
                }

                /* 分页选择器样式 */
                .ant-select-dropdown {
                    background: rgba(16, 20, 34, 0.95) !important;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(0, 194, 255, 0.3);
                }

                .ant-select-item {
                    color: #00ffff !important;
                }

                .ant-select-item-option-selected {
                    background: rgba(0, 40, 120, 0.4) !important;
                }

                .ant-select-item-option-active {
                    background: rgba(0, 40, 120, 0.6) !important;
                }

                .ant-pagination-options .ant-select-selector {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border: 1px solid rgba(0, 194, 255, 0.5) !important;
                    color: #00ffff !important;
                }

                .ant-select-arrow {
                    color: #00ffff !important;
                }

                .ant-pagination-options-quick-jumper {
                    color: #00ffff !important;
                }

                .ant-pagination-options-quick-jumper input {
                    background: rgba(0, 40, 120, 0.4) !important;
                    border: 1px solid rgba(0, 194, 255, 0.5) !important;
                    color: #00ffff !important;
                }

                .ant-pagination-options-quick-jumper input:focus {
                    border-color: rgba(0, 194, 255, 0.8) !important;
                    box-shadow: 0 0 0 2px rgba(0, 194, 255, 0.2) !important;
                }

                /* 分页文字颜色 */
                .ant-pagination {
                    color: #fff !important;
                }

                .ant-select-selection-item {
                    color: #fff !important;
                }

                .ant-popover.ant-popconfirm {
                    z-index: 1000;
                }

                .ant-popover.ant-popconfirm .ant-popover-content {
                    background: rgba(16, 20, 34, 0.95) !important;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(0, 194, 255, 0.3);
                    border-radius: 8px;
                }

                .ant-popover.ant-popconfirm .ant-popover-arrow {
                    display: none;
                }

                .ant-popover.ant-popconfirm .ant-popover-inner {
                    background: transparent !important;
                    box-shadow: none !important;
                }

                .ant-popover.ant-popconfirm .ant-popover-inner-content {
                    color: #fff !important;
                    padding: 12px 16px !important;
                }

                .ant-popover.ant-popconfirm .ant-popover-message {
                    color: #fff !important;
                    padding: 0 0 12px 0 !important;
                }

                .ant-popover.ant-popconfirm .ant-popover-message > .anticon {
                    color: #ff4d4f !important;
                    font-size: 16px !important;
                }

                .ant-popover.ant-popconfirm .ant-popover-message-title {
                    color: #fff !important;
                    padding-left: 22px !important;
                }
            `}</style>
        </div>
    );
};

export default ManageUsers; 