const mongoose = require('mongoose');

const PostsSchema = new mongoose.Schema({
    // 标题
    title: {
        type: String,
        required: true,
        unique: true
    },
    // 描述
    desc: {
        type: String,
        required: true
    },
    // 谁创建的
    uid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    // 图片
    img: {
        type: String,
        required: true
    },
    // 类别
    category: {
        type: String,
        required: true
    },
    // 新增活动相关字段
    points: {
        type: Number,
        default: 0
    },
    location: {
        type: String,
        default: ''
    },
    // 活动开始时间
    startTime: {
        type: Date,
        required: true
    },
    // 活动结束时间
    endTime: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        enum: ['upcoming', 'ongoing', 'completed'],
        default: 'upcoming'
    },
    maxParticipants: {
        type: Number,
        default: 0
    },
    currentParticipants: {
        type: Number,
        default: 0
    },
    tags: [{
        type: String
    }],
    // 点赞数
    likes: {
        type: Number,
        default: 0
    },
    // 点赞用户列表
    likedBy: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Posts', PostsSchema);
