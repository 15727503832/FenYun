import React, { useState } from 'react'
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { uploadFile } from "../utils/api/files/index.js";
import { useLocation, useNavigate } from "react-router-dom";
import { addPost, editPost } from "../utils/api/posts/index.js";
import { message } from "antd";


const Write = () => {

    const state = useLocation().state
    const navigate = useNavigate()

    const [value, setValue] = useState(state?.activity?.desc || '');
    const [title, setTitle] = useState(state?.activity?.title || '');
    const [file, setFile] = useState(null);
    const [previewUrl, setPreviewUrl] = useState('');
    const [category, setCategory] = useState(state?.activity?.category || '学习');
    const [points, setPoints] = useState(state?.activity?.points || 0);
    const [location, setLocation] = useState(state?.activity?.location || '');
    const [startTime, setStartTime] = useState(state?.activity?.startTime ? new Date(state.activity.startTime).toISOString().slice(0,16) : '');
    const [endTime, setEndTime] = useState(state?.activity?.endTime ? new Date(state.activity.endTime).toISOString().slice(0,16) : '');
    const [maxParticipants, setMaxParticipants] = useState(state?.activity?.maxParticipants || 0);
    const [tags, setTags] = useState(state?.activity?.tags ? state.activity.tags.join(',') : '');
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const [successMessage, setSuccessMessage] = useState('');

    // 获取当前时间（精确到分钟，格式为 yyyy-MM-ddTHH:mm）
    const getNowString = () => {
        const now = new Date();
        now.setSeconds(0, 0);
        const pad = n => n < 10 ? '0' + n : n;
        return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`;
    };
    const minActivityTime = getNowString();

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
            setFile(selectedFile);
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviewUrl(reader.result);
            };
            reader.readAsDataURL(selectedFile);
        }
    };

    const handleCancelImage = () => {
        setFile(null);
        setPreviewUrl('');
        const fileInput = document.getElementById('file');
        if (fileInput) fileInput.value = '';
    };

    const upload = async () => {
        if (!file) return null;
        const formData = new FormData();
        formData.append("file", file);
        try {
            const res = await uploadFile(formData);
            return res?.data;
        } catch (err) {
            message.error('图片上传失败');
            return null;
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        // 前端必填校验
        if (
            !title ||
            !value ||
            !category ||
            points === '' || points === null || isNaN(points) ||
            !location ||
            !startTime ||
            !endTime
        ) {
            message.error('请填写所有必填项');
            return;
        }
        // 校验时间
        if (new Date(startTime) < new Date(minActivityTime)) {
            message.error('开始时间不能早于当前时间');
            return;
        }
        if (new Date(endTime) <= new Date(startTime)) {
            message.error('结束时间必须晚于开始时间');
            return;
        }
        let fileUrl = null;
        if (file) {
            fileUrl = await upload();
            if (!fileUrl) return;
        }
        if (!fileUrl && !(state?.activity?.img)) {
            message.error('请上传活动图片');
            return;
        }
        const newPost = {
            title,
            desc: value,
            category,
            img: fileUrl || state?.activity?.img,
            points: Number(points),
            location,
            startTime,
            endTime,
            status: 'upcoming',
            maxParticipants: Number(maxParticipants),
            tags: tags.split(',').map(tag => tag.trim())
        };
        try {
            if (state) {
                const res = await editPost(state.activity._id, { ...newPost, _id: state.activity._id });
                if (res?.code === 200) {
                    setSuccessMessage('活动修改成功');
                    setShowSuccessModal(true);
                    localStorage.setItem('pointsChange', '20');
                    setTimeout(() => {
                        setShowSuccessModal(false);
                        navigate('/');
                    }, 2000);
                } else {
                    message.error(res?.msg);
                }
            } else {
                const res = await addPost(newPost);
                if (res?.code === 200) {
                    setSuccessMessage('活动发布成功，获得20积分！');
                    setShowSuccessModal(true);
                    localStorage.setItem('pointsChange', '20');
                    setTimeout(() => {
                        setShowSuccessModal(false);
                        navigate('/');
                    }, 2000);
                } else {
                    message.error(res?.msg);
                }
            }
        } catch (err) {
            message.error('发布失败，请重试');
        }
    }

    return (
        <div className='write-page'>
            {showSuccessModal && (
                <div style={{
                    position: 'fixed',
                    top: '20px',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    background: 'rgba(0, 200, 83, 0.9)',
                    padding: '16px 32px',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '16px',
                    zIndex: 1000,
                    animation: 'slideDown 0.3s ease-in-out',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                }}>
                    <span style={{ fontSize: '20px' }}>✨</span>
                    {successMessage}
                </div>
            )}
            <div className="write-container">
                <div className="editor-section">
                    <input 
                        className="title-input"
                        type="text"
                        value={title}
                        placeholder="活动名称"
                        onChange={e => setTitle(e.target.value)}
                    />
                    <div className="editor-wrapper">
                        <ReactQuill 
                            className='editor' 
                            theme="snow" 
                            value={value} 
                            onChange={setValue}
                            placeholder="活动介绍"
                        />
                    </div>
                </div>
                <div className="sidebar">
                    <div className="sidebar-card publish-section">
                        <h2>活动信息</h2>
                        <div className="form-group">
                            <label>活动积分：</label>
                            <input
                                type="number"
                                value={points}
                                onChange={(e) => setPoints(e.target.value)}
                                min="0"
                            />
                        </div>
                        <div className="form-group">
                            <label>活动地点：</label>
                            <input
                                type="text"
                                value={location}
                                onChange={(e) => setLocation(e.target.value)}
                                placeholder="请输入活动地点"
                            />
                        </div>
                        <div className="form-group">
                            <label>开始时间：</label>
                            <input
                                type="datetime-local"
                                value={startTime}
                                onChange={(e) => setStartTime(e.target.value)}
                                min={minActivityTime}
                            />
                        </div>
                        <div className="form-group">
                            <label>结束时间：</label>
                            <input
                                type="datetime-local"
                                value={endTime}
                                onChange={(e) => setEndTime(e.target.value)}
                                min={startTime || minActivityTime}
                            />
                        </div>
                        <div className="form-group">
                            <label>最大参与人数：</label>
                            <input
                                type="number"
                                value={maxParticipants}
                                onChange={(e) => setMaxParticipants(e.target.value)}
                                min="0"
                                placeholder="0表示不限制"
                            />
                        </div>
                        <div className="form-group">
                            <label>活动标签：</label>
                            <input
                                type="text"
                                value={tags}
                                onChange={(e) => setTags(e.target.value)}
                                placeholder="用逗号分隔多个标签"
                            />
                        </div>
                    </div>
                    <div className="sidebar-card category-section">
                        <h2>选择分类</h2>
                        <div className="category-list">
                            {[
                                { id: '学习', label: '学习', icon: '📚' },
                                { id: '运动', label: '运动', icon: '🏃' },
                                { id: '娱乐', label: '娱乐', icon: '🎉' },
                                { id: '其他', label: '其他', icon: '📝' }
                            ].map(item => (
                                <label 
                                    key={item.id} 
                                    className={`category-item ${category === item.id ? 'active' : ''}`}
                                >
                                    <input
                                        type='radio'
                                        name='category'
                                        value={item.id}
                                        checked={category === item.id}
                                        onChange={e => setCategory(e.target.value)}
                                    />
                                    <span className="category-icon">{item.icon}</span>
                                    <span className="category-label">{item.label}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                    <div className="sidebar-card upload-section">
                        <h2>上传活动图片</h2>
                        <input 
                            type='file' 
                            id='file' 
                            name='file' 
                            accept="image/*"
                            style={{ display: 'none' }} 
                            onChange={handleFileChange}
                        />
                        {!previewUrl && !(state?.activity?.img) ? (
                            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 18 }}>
                                <label className='upload-btn' htmlFor='file'>
                                    <i className="fas fa-cloud-upload-alt" style={{ fontSize: 28, marginRight: 8 }}></i>
                                    点击上传
                                </label>
                            </div>
                        ) : (
                            <div className="image-preview-container">
                                <img 
                                    src={previewUrl || state?.activity?.img} 
                                    alt="Preview" 
                                    className="image-preview"
                                />
                                <div className="image-preview-overlay">
                                    <button 
                                        className="change-image-btn"
                                        onClick={() => document.getElementById('file').click()}
                                    >
                                        更换图片
                                    </button>
                                    <button 
                                        className="cancel-image-btn"
                                        onClick={handleCancelImage}
                                    >
                                        取消图片
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                    <div className="publish-btn-wrapper">
                        <button className="publish-btn" onClick={handleSubmit}>
                            发布活动
                        </button>
                    </div>
                </div>
            </div>
            <style jsx="true">{`
                .write-page {
                    min-height: calc(100vh - 60px);
                    padding: 20px;
                    background: linear-gradient(180deg, rgba(0,40,120,0.1) 0%, rgba(0,40,120,0.05) 100%);
                }

                .write-container {
                    max-width: 1400px;
                    margin: 0 auto;
                    display: grid;
                    grid-template-columns: 1fr 300px;
                    gap: 20px;
                }

                .editor-section {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                }

                .title-input {
                    width: 100%;
                    padding: 15px 20px;
                    font-size: 24px;
                    color: #fff;
                    background: rgba(0, 40, 120, 0.2);
                    border: none;
                    border-radius: 12px;
                    outline: none;
                    transition: all 0.3s ease;
                }

                .title-input:focus {
                    background: rgba(0, 40, 120, 0.3);
                    box-shadow: 0 0 20px rgba(0, 194, 255, 0.1);
                }

                .title-input::placeholder {
                    color: rgba(255, 255, 255, 0.5);
                }

                .editor-wrapper {
                    background: rgba(1, 4, 39, 0.9);
                    border-radius: 12px;
                    overflow: hidden;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
                }

                .editor-wrapper .ql-toolbar {
                    background: rgba(2, 9, 53, 0.95);
                    border: none;
                    border-bottom: 1px solid rgba(0, 194, 255, 0.1);
                    padding: 12px;
                }

                .editor-wrapper .ql-container {
                    border: none;
                    height: calc(100vh - 280px);
                    font-size: 16px;
                    background: rgba(1, 4, 39, 0.9);
                }

                .editor-wrapper .ql-editor {
                    padding: 20px;
                    color: #00ffff;
                    font-size: 16px;
                    line-height: 1.6;
                }

                .editor-wrapper .ql-editor::placeholder {
                    color: rgba(0, 255, 255, 0.3);
                }

                .sidebar {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                }

                .sidebar-card {
                    background: rgba(0, 40, 120, 0.2);
                    border-radius: 12px;
                    padding: 20px;
                }

                .sidebar-card h2 {
                    color: #00ffff;
                    font-size: 18px;
                    margin-bottom: 20px;
                    font-weight: 500;
                }

                .form-group {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }

                .form-group label {
                    color: rgba(255, 255, 255, 0.6);
                }

                .form-group input {
                    width: 100%;
                    padding: 12px;
                    background: rgba(0, 40, 120, 0.3);
                    border: none;
                    border-radius: 8px;
                    color: #00ffff;
                }

                .publish-btn {
                    width: 100%;
                    padding: 12px;
                    background: rgba(0, 194, 255, 0.2);
                    border: none;
                    border-radius: 8px;
                    color: #00ffff;
                    font-size: 16px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .publish-btn:hover {
                    background: rgba(0, 194, 255, 0.3);
                    transform: translateY(-2px);
                }

                .category-list {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                }

                .category-item {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    padding: 10px;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }

                .category-item input {
                    display: none;
                }

                .category-item .category-icon {
                    font-size: 20px;
                    opacity: 0.7;
                    transition: all 0.3s ease;
                }

                .category-item .category-label {
                    color: rgba(255, 255, 255, 0.8);
                    transition: all 0.3s ease;
                }

                .category-item:hover {
                    background: rgba(0, 194, 255, 0.1);
                }

                .category-item.active {
                    background: rgba(0, 194, 255, 0.2);
                }

                .category-item.active .category-icon {
                    opacity: 1;
                }

                .category-item.active .category-label {
                    color: #00ffff;
                }

                /* 编辑器工具栏样式 */
                .ql-snow .ql-stroke {
                    stroke: #00ffff;
                }

                .ql-snow .ql-fill {
                    fill: #00ffff;
                }

                .ql-snow .ql-picker {
                    color: #00ffff;
                }

                .ql-snow .ql-picker-options {
                    background: rgba(2, 9, 53, 0.98);
                    border: 1px solid rgba(0, 194, 255, 0.1);
                    padding: 5px 0;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                }

                .ql-snow .ql-picker-item {
                    color: #00ffff;
                    padding: 6px 12px;
                }

                .ql-snow .ql-picker-item:hover {
                    color: #fff;
                    background: rgba(0, 194, 255, 0.15);
                }

                .ql-snow .ql-formats button {
                    width: 28px;
                    height: 28px;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    padding: 0;
                    margin: 0 2px;
                    border-radius: 4px;
                }

                .ql-snow .ql-formats button:hover {
                    background: rgba(0, 194, 255, 0.15);
                }

                .ql-snow .ql-formats button:hover .ql-stroke {
                    stroke: #fff;
                }

                .ql-snow .ql-formats button:hover .ql-fill {
                    fill: #fff;
                }

                .ql-snow button.ql-active,
                .ql-snow .ql-picker.ql-expanded .ql-picker-label {
                    background: rgba(0, 194, 255, 0.15);
                }

                .ql-snow button.ql-active .ql-stroke,
                .ql-snow .ql-picker.ql-expanded .ql-picker-label .ql-stroke {
                    stroke: #fff;
                }

                .ql-snow button.ql-active .ql-fill,
                .ql-snow .ql-picker.ql-expanded .ql-picker-label .ql-fill {
                    fill: #fff;
                }

                .ql-snow .ql-formats {
                    margin-right: 12px;
                    padding-right: 12px;
                    border-right: 1px solid rgba(0, 194, 255, 0.1);
                }

                .ql-snow .ql-formats:last-child {
                    margin-right: 0;
                    padding-right: 0;
                    border-right: none;
                }

                /* 响应式设计 */
                @media (max-width: 1024px) {
                    .write-container {
                        grid-template-columns: 1fr;
                    }

                    .sidebar {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    }
                }

                @media (max-width: 768px) {
                    .sidebar {
                        grid-template-columns: 1fr;
                    }
                }

                .image-preview-container {
                    position: relative;
                    width: 100%;
                    aspect-ratio: 16/9;
                    border-radius: 8px;
                    overflow: hidden;
                    margin-bottom: 20px;
                }

                .image-preview {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    transition: transform 0.3s ease;
                }

                .image-preview-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 40, 120, 0.7);
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    gap: 10px;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }

                .image-preview-container:hover .image-preview-overlay {
                    opacity: 1;
                }

                .image-preview-container:hover .image-preview {
                    transform: scale(1.05);
                }

                .change-image-btn,
                .cancel-image-btn {
                    padding: 8px 16px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;
                    transition: all 0.3s ease;
                    background: rgba(0, 194, 255, 0.2);
                    color: #fff;
                }

                .change-image-btn:hover {
                    background: rgba(0, 194, 255, 0.3);
                }

                .cancel-image-btn {
                    background: rgba(255, 69, 58, 0.2);
                }

                .cancel-image-btn:hover {
                    background: rgba(255, 69, 58, 0.3);
                }

                .upload-btn {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 10px;
                    min-width: 160px;
                    padding: 18px 0;
                    background: linear-gradient(90deg, #00f0ff 0%, #007bff 100%);
                    border: 2px dashed #00f0ff88;
                    border-radius: 12px;
                    color: #fff;
                    font-size: 18px;
                    font-weight: bold;
                    cursor: pointer;
                    box-shadow: 0 2px 12px #00f0ff33;
                    transition: background 0.2s, border 0.2s, transform 0.2s;
                }

                .upload-btn:hover {
                    background: linear-gradient(90deg, #00cfff 0%, #005fff 100%);
                    border: 2px solid #00f0ff;
                    transform: scale(1.05);
                    color: #fff;
                }

                .publish-btn-wrapper {
                    display: flex;
                    justify-content: center;
                    margin-top: 28px;
                }

                @keyframes slideDown {
                    from {
                        opacity: 0;
                        transform: translate(-50%, -100%);
                    }
                    to {
                        opacity: 1;
                        transform: translate(-50%, 0);
                    }
                }
            `}</style>
        </div>
    )
}
export default Write
