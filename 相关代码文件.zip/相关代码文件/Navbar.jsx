import React, { useContext, useState, useEffect, useRef } from 'react';
import Logo from '../img/logo.png';
import { Link, useLocation, useNavigate } from "react-router-dom";
import { UserContext } from "../context/userContext.jsx";
import DefaultAvatar from '../img/touxiang.png'; // 重命名为DefaultAvatar更清晰
import axios from 'axios';
import RankingDropdownPortal from './RankingDropdownPortal';
import AnnouncementModal from './AnnouncementModal';
import { message, Modal, Dropdown } from 'antd';
import { DownOutlined } from '@ant-design/icons';

// API基础路径
const API_BASE_URL = 'http://localhost:7777';

const pointRules = [
  { icon: '🎉', text: '注册新用户：+10分', type: 'register' },
  { icon: '📝', text: '完善个人资料：+5分', type: 'profile' },
  { icon: '📢', text: '发布新活动：+20分', type: 'post' },
  { icon: '🤝', text: '参与活动：+10分', type: 'participate' },
  { icon: '👍', text: '活动被点赞：+5分', type: 'liked' },
  { icon: '📅', text: '每日签到：+2分', type: 'checkin' },
  { icon: '📱', text: '分享活动到社交媒体：+5分', type: 'share' },
];
const getUserLevel = (points) => {
    if (points >= 1000) return { level: '钻石', color: '#00ffff', title: '荣誉导师', background: 'rgba(0,255,255,0.1)' };
    if (points >= 600)  return { level: '铂金', color: '#b0e0e6', title: '核心贡献者', background: 'rgba(176,224,230,0.1)' };
    if (points >= 300)  return { level: '黄金', color: '#ffd700', title: '社团明星', background: 'rgba(255,215,0,0.1)' };
    if (points >= 100)  return { level: '白银', color: '#c0c0c0', title: '活跃参与者', background: 'rgba(192,192,192,0.1)' };
    return { level: '青铜', color: '#cd7f32', title: '初级探索者', background: 'rgba(205,127,50,0.1)' };
};

// 统一按钮基础样式（美化升级）
const navBtnBase = {
  height: '48px',
  minWidth: '132px',
  padding: '0 36px',
  borderRadius: '28px',
  fontSize: '19px',
  fontWeight: 700,
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  border: '1.5px solid rgba(255,255,255,0.18)',
  cursor: 'pointer',
  background: 'linear-gradient(90deg, rgba(224,234,255,0.85) 0%, rgba(255,224,233,0.85) 100%)',
  color: '#2a3a5c',
  boxShadow: '0 4px 24px 0 rgba(75, 108, 255, 0.13)',
  transition: 'all 0.22s cubic-bezier(.4,2,.6,1)',
  backdropFilter: 'blur(8px)',
  fontFamily: 'PingFang SC, HarmonyOS Sans, Poppins, Arial, sans-serif',
  marginLeft: '24px',
  outline: 'none',
  position: 'relative',
  overflow: 'hidden',
};

const categoryList = [
  { key: '学习', icon: '📚', label: '学习' },
  { key: '运动', icon: '🏃‍♂️', label: '运动' },
  { key: '娱乐', icon: '🎉', label: '娱乐' },
  { key: '其他', icon: '📝', label: '其他' }
];

const Navbar = () => {
    const { currentUser, logout, updateCurrentUser } = useContext(UserContext);
    const location = useLocation();
    const navigate = useNavigate();
    const [showDropdown, setShowDropdown] = useState(false); // 控制显示下拉框的状态
    const [showRanking, setShowRanking] = useState(false);
    const [topActivities, setTopActivities] = useState([]);
    const rankingRef = useRef(null);
    const [showPointRule, setShowPointRule] = useState(false);
    const rankingBtnRef = useRef();
    const [rankingBtnPos, setRankingBtnPos] = useState({top: 0, left: 0, width: 0, height: 0});
    const [showPointRank, setShowPointRank] = useState(false);
    const [pointRankList, setPointRankList] = useState([]);
    const [showAnnouncement, setShowAnnouncement] = useState(false);
    const [announcements, setAnnouncements] = useState([]);
    const [showPointsAnim, setShowPointsAnim] = useState(false);
    const [lastPointsChange, setLastPointsChange] = useState(0);
    const [openDropdown, setOpenDropdown] = useState(null);

    // 获取排行榜数据
    const fetchTopActivities = async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/api/posts?sort=participants`);
            if (response.data.code === 200) {
                setTopActivities(response.data.data.slice(0, 10)); // 只取前10个
            }
        } catch (error) {
            console.error('获取排行榜数据失败:', error);
        }
    };

    // 组件加载时获取排行榜数据
    useEffect(() => {
        fetchTopActivities();
    }, []);

    // 点击外部关闭排行榜
    useEffect(() => {
        function handleClickOutside(event) {
            if (rankingRef.current && !rankingRef.current.contains(event.target)) {
                setShowRanking(false);
            }
        }
        if (showRanking) {
            document.addEventListener('mousedown', handleClickOutside);
        } else {
            document.removeEventListener('mousedown', handleClickOutside);
        }
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [showRanking]);

    useEffect(() => {
        if (showRanking && rankingBtnRef.current) {
            const rect = rankingBtnRef.current.getBoundingClientRect();
            setRankingBtnPos(rect);
        }
    }, [showRanking]);

    // 获取用户头像URL
    const getAvatarUrl = () => {
        if (!currentUser) return DefaultAvatar;
        if (!currentUser.img) return DefaultAvatar;
        if (currentUser.img.startsWith('http')) return currentUser.img;
        return `${API_BASE_URL}${currentUser.img}`;
    };

    // 处理点击头像的函数
    const handleAvatarClick = () => {
        setShowDropdown(!showDropdown); // 点击头像时切换显示状态
    };

    // 处理编辑个人资料选项的函数
    const handleEditProfile = () => {
        // 示例：跳转到编辑个人资料页面，并携带 currentUser._id
        navigate(`/userinformation/${currentUser._id}`);
        setShowDropdown(false); // 点击后隐藏下拉框
    };

    // 处理管理用户选项的函数
    const handleManageUsers = () => {
        navigate('/manage-users');
        setShowDropdown(false);
    };

    // 处理退出登录的函数
    const handleLogout = () => {
        logout(); // 执行退出登录操作（清空用户信息等）
        navigate('/login'); // 跳转到登录页面
    };

    // 获取积分排行榜数据
    const fetchPointRankList = async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/api/users/points-ranking`);
            if (response.data && response.data.code === 200 && Array.isArray(response.data.data)) {
                setPointRankList(response.data.data.slice(0, 10)); // 只取前10个
            } else {
                setPointRankList([]);
            }
        } catch (error) {
            setPointRankList([]);
            console.error('获取积分排行榜数据失败:', error);
        }
    };

    // 组件加载时获取积分排行榜数据
    useEffect(() => {
        fetchPointRankList();
    }, []);

    const fetchAnnouncements = async () => {
        try {
            const res = await axios.get(`${API_BASE_URL}/api/announcements`);
            if (res.data && res.data.code === 200) setAnnouncements(res.data.data);
        } catch {}
    };

    useEffect(() => { fetchAnnouncements(); }, []);

    // 新增：监听localStorage积分变化（注册、发布、完善资料后主动触发）
    useEffect(() => {
        const handleStorage = (e) => {
            if (e.key === 'pointsChange' && e.newValue) {
                setLastPointsChange(Number(e.newValue));
                setShowPointsAnim(true);
                setTimeout(() => setShowPointsAnim(false), 1500);
                setTimeout(() => localStorage.removeItem('pointsChange'), 2000);
            }
        };
        window.addEventListener('storage', handleStorage);
        return () => window.removeEventListener('storage', handleStorage);
    }, []);

    // 检查用户是否完成过某项积分规则
    const checkRuleCompletion = (ruleType) => {
        if (!currentUser) return false;
        
        switch (ruleType) {
            case 'register':
                return true; // 注册后默认完成
            case 'profile':
                return currentUser.perfectProfileRewarded; // 是否已因完善资料获得过积分
            case 'post':
                return currentUser.hasPostedActivity; // 是否发布过活动
            case 'participate':
                return currentUser.participatedActivities?.length > 0; // 是否参与过活动
            case 'liked':
                return currentUser.receivedLikes > 0; // 是否收到过点赞
            case 'checkin':
                // 判断 lastCheckinDate 是否为今天
                return currentUser.lastCheckinDate === new Date().toISOString().slice(0, 10);
            case 'share':
                // 只要用户分享过任意活动就算完成
                return currentUser.sharedActivities && currentUser.sharedActivities.length > 0;
            default:
                return false;
        }
    };

    const handleCheckin = async () => {
        const res = await axios.post('/users/checkin', {}, { withCredentials: true });
        if (res.data.code === 200) {
            // 刷新用户信息
            const userRes = await axios.get(`/api/users/${currentUser._id}`);
            if (userRes.data.code === 200) {
                updateCurrentUser(userRes.data.data);
            }
            alert('签到成功，获得2积分！');
        } else {
            alert(res.data.msg);
        }
    };

    // 检查是否是管理员
    useEffect(() => {
        if (!currentUser?.isAdmin) {
            message.error('您没有权限访问此页面');
            navigate('/');
        }
    }, [currentUser, navigate]);

    const handleCategoryClick = ({ key }) => {
        navigate(`/?category=${key}`);
    };

    const categoryItems = categoryList.map(item => ({
        key: item.key,
        label: (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '18px' }}>{item.icon}</span>
                <span>{item.label}</span>
            </div>
        ),
    }));

    return (
        <div className='navbar'>
            <div className='container navbar-container'>
                <div className="logo">
                    <Link to='/'>
                        <img src={Logo} alt=""/>
                    </Link>
                </div>
                <div className="links" style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
                  {!currentUser?.isAdmin && (
                    <>
                      <Dropdown
                        menu={{
                            items: categoryItems,
                            onClick: handleCategoryClick,
                        }}
                        placement="bottomCenter"
                      >
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4,
                            padding: '8px 16px',
                            borderRadius: 10,
                            border: '1.5px solid #b2f7ef',
                            background: 'rgba(0,40,120,0.12)',
                            color: '#00eaff',
                            fontWeight: 700,
                            fontSize: 13,
                            cursor: 'pointer',
                            transition: 'all 0.18s',
                            userSelect: 'none',
                            minWidth: 100,
                            marginRight: '12px'
                          }}
                          onMouseOver={e => e.currentTarget.style.filter = 'brightness(1.08)'}
                          onMouseOut={e => e.currentTarget.style.filter = 'none'}
                        >
                          <span style={{ fontSize: 22 }}>📋</span>
                          <span>分类导航</span>
                          <DownOutlined style={{ marginLeft: '4px', fontSize: '12px' }} />
                        </div>
                      </Dropdown>
                    </>
                  )}
                  {currentUser ? (
                    <div className="avatar-container" style={{ position: 'relative', marginLeft: 16 }}>
                      <div
                        className="avatar-wrapper"
                        onClick={handleAvatarClick}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          cursor: 'pointer',
                          padding: '6px 10px',
                          borderRadius: '30px',
                          background: 'rgba(0, 40, 120, 0.15)',
                          transition: 'all 0.3s ease',
                          gap: '12px'
                        }}
                      >
                        <img
                          src={getAvatarUrl()}
                          alt='Avatar'
                          style={{
                            width: '42px',
                            height: '42px',
                            borderRadius: '50%',
                            objectFit: 'cover',
                            boxShadow: '0 0 12px rgba(0, 194, 255, 0.3)'
                          }}
                        />

                        <div style={{ display: 'flex', flexDirection: 'column' }}>
                          <div style={{ color: '#00ffff', fontWeight: 700 }}>
                            {currentUser.username}
                          </div>

                          <div style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 8,
                            marginTop: 4,
                            flexWrap: 'wrap'
                          }}>
                            <span style={{ color: '#ffd700', fontWeight: 700 }}>
                              {currentUser?.points ?? 0}
                              <span
                                className={`points-badge${showPointsAnim ? ' show' : ''}`}
                                style={{
                                  marginLeft: 4,
                                  color: '#00ffcc',
                                  fontWeight: 600,
                                  fontSize: '0.75em'
                                }}
                              >
                                +{lastPointsChange}
                              </span>
                              <span style={{ marginLeft: 4, fontSize: '0.75em' }}>积分</span>
                            </span>

                            {(() => {
                              const { level, color, title, background } = getUserLevel(currentUser?.points ?? 0);
                              return (
                                <span style={{
                                  fontSize: '0.75em',
                                  padding: '2px 8px',
                                  borderRadius: '12px',
                                  color,
                                  background,
                                  fontWeight: 600
                                }}>
                                  {title}（{level}）
                                </span>
                              );
                            })()}

                            {currentUser.isAdmin ? (
                              <span style={{
                                fontSize: '0.75em',
                                padding: '2px 6px',
                                borderRadius: '10px',
                                background: 'rgba(255, 0, 255, 0.1)',
                                color: '#ff00ff',
                                fontWeight: 600
                              }}>
                                系统管理员
                              </span>
                            ) : currentUser.isClubAdmin ? (
                              <span style={{
                                fontSize: '0.75em',
                                padding: '2px 6px',
                                borderRadius: '10px',
                                background: 'rgba(0, 191, 255, 0.1)',
                                color: '#00bfff',
                                fontWeight: 600
                              }}>
                                社团管理员
                              </span>
                            ) : (
                              <span style={{
                                fontSize: '0.75em',
                                padding: '2px 6px',
                                borderRadius: '10px',
                                background: 'rgba(0, 255, 153, 0.1)',
                                color: '#00ff99',
                                fontWeight: 600
                              }}>
                                学生
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {showDropdown && (
                        <div className="dropdown" style={{
                          position: 'absolute',
                          top: '60px',
                          right: 0,
                          backgroundColor: 'rgba(16, 20, 34, 0.95)',
                          backdropFilter: 'blur(10px)',
                          borderRadius: '10px',
                          overflow: 'hidden',
                          minWidth: '180px',
                          boxShadow: '0 0 30px rgba(0, 194, 255, 0.15)',
                          animation: 'dropdownFade 0.3s ease',
                          zIndex: 3000
                        }}>
                          <div
                            onClick={handleEditProfile}
                            style={{
                              padding: '12px 20px',
                              color: '#00ffff',
                              cursor: 'pointer',
                              transition: 'all 0.3s ease',
                              borderBottom: '1px solid rgba(0, 194, 255, 0.1)',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px'
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.backgroundColor = 'rgba(0, 194, 255, 0.1)';
                              e.currentTarget.style.transform = 'translateX(5px)';
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.backgroundColor = 'transparent';
                              e.currentTarget.style.transform = 'translateX(0)';
                            }}
                          >
                            <i className="fas fa-user-edit" style={{ fontSize: '14px' }}></i>
                            编辑个人资料
                          </div>

                          <div
                            onClick={handleLogout}
                            style={{
                              padding: '12px 20px',
                              color: '#ff4d4f',
                              cursor: 'pointer',
                              transition: 'all 0.3s ease',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px'
                            }}
                            onMouseEnter={e => {
                              e.currentTarget.style.backgroundColor = 'rgba(255, 77, 79, 0.1)';
                              e.currentTarget.style.transform = 'translateX(5px)';
                            }}
                            onMouseLeave={e => {
                              e.currentTarget.style.backgroundColor = 'transparent';
                              e.currentTarget.style.transform = 'translateX(0)';
                            }}
                          >
                            <i className="fas fa-sign-out-alt" style={{ fontSize: '14px' }}></i>
                            退出登录
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link to='/login' style={{
                      color: '#00ffff',
                      textDecoration: 'none',
                      padding: '8px 16px',
                      borderRadius: '20px',
                      background: 'rgba(0, 40, 120, 0.2)',
                      transition: 'all 0.3s ease',
                      display: 'inline-block',
                      marginLeft: 16
                    }}>
                      请登录
                    </Link>
                  )}
                  {/* 右侧垂直排列容器 */}
                  <div style={{
                    position: 'fixed',        // 固定在页面右侧
                    top: '20%',              // 距离顶部20%
                    right: '20px',           // 距离右边20px
                    display: 'flex',
                    flexDirection: 'column', // 垂直排列
                    gap: '12px',             // 按钮之间间距
                    zIndex: 10000,
                    alignItems: 'flex-end',  // 右对齐内容
                  }}></div>
                  
                  {/* 管理员功能按钮 */}
                  {currentUser?.isAdmin && (
                    <>
                      <div 
                        onClick={() => {navigate('/manage-users')}}
                        style={{
                          ...navBtnBase,
                          background: 'linear-gradient(90deg, #ff6b6b 0%, #cc2e5d 100%)',
                          color: '#fff',
                          minWidth: '100px',
                          fontWeight: 900,
                          boxShadow: '0 6px 24px 0 rgba(255, 107, 107, 0.15)',
                          padding: '4px 10px',
                          cursor: 'pointer',
                          borderRadius: '6px',
                          marginLeft: '16px'
                        }}
                      >
                        <span className='link' style={{
                          color: 'inherit',
                          fontSize: '20px',
                          fontWeight: 'bold',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '10px',
                          letterSpacing: '2px',
                          fontFamily: 'inherit',
                        }}>
                          <i className="fas fa-users-cog" style={{ fontSize: '20px', transition: 'transform 0.22s' }}></i>
                          用户管理
                        </span>
                      </div>
                    </>
                  )}

                  {/* 社团管理员功能按钮 */}
                  {currentUser?.isClubAdmin && (
                    <div 
                      className='write' 
                      onClick={() => {navigate('/write')}}
                      style={{
                        ...navBtnBase,
                        background: 'linear-gradient(90deg, #00c8db 0%, #3670b5 100%)',
                        color: '#fff',
                        minWidth: '100px',
                        fontWeight: 900,
                        boxShadow: '0 6px 24px 0 rgba(0, 200, 220, 0.15)',
                        padding: '4px 10px',
                        cursor: 'pointer',
                        borderRadius: '6px',
                        marginLeft: '16px'
                      }}
                    >
                      <span className='link' style={{
                        color: 'inherit',
                        fontSize: '20px',
                        fontWeight: 'bold',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        letterSpacing: '2px',
                        fontFamily: 'inherit',
                      }}>
                        <i className="fas fa-pen-fancy" style={{ fontSize: '20px', transition: 'transform 0.22s' }}></i>
                        发布活动
                      </span>
                    </div>
                  )}

                  {/* 非管理员功能按钮 */}
                  {!currentUser?.isAdmin && (
                    <>
                      {/* 排行榜按钮和悬浮框包裹在ref中 */}
                      <div style={{ position: 'relative', display: 'inline-block' }} ref={rankingRef}>
                        <div 
                          ref={rankingBtnRef}
                          className="ranking-button"
                          onClick={() => setShowRanking(v => !v)}
                          style={{
                            ...navBtnBase,
                            background: 'linear-gradient(90deg, #0a1a3a 0%, #1a2a5a 100%)',
                            color: '#fff',
                            fontWeight: 800,
                            minWidth: '90px',
                            padding: '4px 10px',
                            cursor: 'pointer',
                            borderRadius: '6px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <span style={{fontSize: '26px', lineHeight: 1, marginRight: '8px', transition: 'transform 0.22s'}}>🔥</span>
                          <span style={{fontSize: '19px', fontWeight: 'bold', letterSpacing: '2px'}}>排行榜</span>
                        </div>
                        {showRanking && (
                          <RankingDropdownPortal>
                            <div 
                              className="ranking-dropdown"
                              style={{
                                position: 'fixed',
                                top: rankingBtnPos.top + rankingBtnPos.height + 10,
                                left: rankingBtnPos.left + rankingBtnPos.width + 40,
                                backgroundColor: 'rgba(16, 20, 34, 0.95)',
                                backdropFilter: 'blur(10px)',
                                borderRadius: '10px',
                                padding: '15px',
                                minWidth: '300px',
                                boxShadow: '0 0 30px rgba(0, 194, 255, 0.15)',
                                zIndex: 9999,
                                marginTop: 0
                              }}
                            >
                              <h3 style={{ 
                                color: '#00ffff', 
                                marginBottom: '15px',
                                textAlign: 'center',
                                borderBottom: '1px solid rgba(0, 194, 255, 0.2)',
                                paddingBottom: '10px'
                              }}>
                                热门活动排行
                              </h3>
                              {topActivities.map((activity, index) => (
                                <div 
                                  key={activity._id}
                                  onClick={() => navigate(`/posts/${activity._id}`)}
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    padding: '10px',
                                    marginBottom: '8px',
                                    borderRadius: '8px',
                                    cursor: 'pointer',
                                    transition: 'all 0.3s ease',
                                    background: index < 3 ? 'rgba(0, 194, 255, 0.1)' : 'transparent'
                                  }}
                                >
                                  <span style={{
                                    width: '24px',
                                    height: '24px',
                                    borderRadius: '50%',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    marginRight: '10px',
                                    background: index < 3 ? '#00ffff' : 'rgba(0, 194, 255, 0.2)',
                                    color: index < 3 ? '#000' : '#00ffff',
                                    fontWeight: 'bold'
                                  }}>
                                    {index + 1}
                                  </span>
                                  <div style={{ flex: 1 }}>
                                    <div style={{ color: '#00ffff', marginBottom: '4px', display: 'flex', alignItems: 'center', fontWeight: 'bold', fontSize: '18px' }}>
                                      {activity.title}
                                      {index === 0 && <span style={{marginLeft: '6px', fontSize: '20px'}}>✨✨✨</span>}
                                      {index === 1 && <span style={{marginLeft: '6px', fontSize: '20px'}}>✨✨</span>}
                                      {index === 2 && <span style={{marginLeft: '6px', fontSize: '20px'}}>✨</span>}
                                    </div>
                                    <div style={{ 
                                      fontSize: '12px', 
                                      color: '#888',
                                      display: 'flex',
                                      justifyContent: 'space-between'
                                    }}>
                                      <span>参与人数: {activity.currentParticipants}</span>
                                      <span>积分: {activity.points}</span>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </RankingDropdownPortal>
                        )}
                      </div>

                      {/* 积分规则按钮 */}
                      <button
                          onClick={() => setShowPointRule(true)}
                          style={{
                              ...navBtnBase,
                              background: 'linear-gradient(90deg, #ffd0d9 0%, #a2e7df 100%)',
                              color: '#e65a9f',
                              fontWeight: 800,
                              minWidth: '80px',
                              padding: '4px 10px',
                          }}
                      >
                          <span style={{ fontSize: '26px', marginRight: '8px', transition: 'transform 0.22s' }}>🧸</span>
                          <span style={{
                            fontSize: '19px',
                            fontWeight: 'bold',
                            background: 'linear-gradient(45deg, #ff4b4b 0%, #4169e1 100%)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            backgroundClip: 'text'
                          }}>积分规则</span>
                      </button>
                      <Modal
                        open={showPointRule}
                        onCancel={() => setShowPointRule(false)}
                        footer={null}
                        title="积分规则"
                        centered
                      >
                        <ul style={{padding: 0, margin: 0, listStyle: 'none'}}>
                          {pointRules.map(rule => (
                            <li key={rule.type} style={{display: 'flex', alignItems: 'center', marginBottom: 12, fontSize: 17, color: '#222'}}>
                              <span style={{fontSize: 22, marginRight: 10}}>{rule.icon}</span>
                              <span style={{color: '#222', fontWeight: 500}}>{rule.text}</span>
                            </li>
                          ))}
                        </ul>
                      </Modal>

                      {/* 积分排行榜按钮 */}
                      <button
                          onClick={() => { fetchPointRankList(); setShowPointRank(true); }}
                          style={{
                              ...navBtnBase,
                              background: 'linear-gradient(90deg, #d0daef 0%, #ffd0d9 100%)',
                              color: '#2a4cef',
                              fontWeight: 800,
                              minWidth: '80px',
                              padding: '4px 10px',
                          }}
                      >
                          <span style={{ fontSize: '26px', marginRight: '8px', transition: 'transform 0.22s' }}>🏆</span>
                          <span style={{
                            fontSize: '19px',
                            fontWeight: 'bold',
                            background: 'linear-gradient(45deg, #ff4b4b 0%, #4169e1 100%)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            backgroundClip: 'text'
                          }}>积分排行榜</span>
                      </button>
                      <Modal
                        open={showPointRank}
                        onCancel={() => setShowPointRank(false)}
                        footer={null}
                        title="积分排行榜"
                        centered
                      >
                        <ol style={{paddingLeft: 20, margin: 0}}>
                          {pointRankList.length === 0 && <li style={{color: '#222'}}>暂无数据</li>}
                          {pointRankList.map((user, idx) => (
                            <li key={user._id || idx} style={{marginBottom: 12, fontSize: 17, display: 'flex', alignItems: 'center', color: '#222'}}>
                              <span style={{fontWeight: 'bold', color: idx === 0 ? '#ffd700' : idx === 1 ? '#c0c0c0' : idx === 2 ? '#cd7f32' : '#00eaff', fontSize: 20, marginRight: 10}}>{idx + 1}</span>
                              <span style={{marginRight: 10, minWidth: 80, color: '#222', fontWeight: 500}}>{user.username || '匿名用户'}</span>
                              <span style={{color: '#00aaff', fontWeight: 600}}>积分: {user.points}</span>
                            </li>
                          ))}
                        </ol>
                      </Modal>

                      {/* 通知公告按钮 */}
                      <button
                          onClick={() => { setShowAnnouncement(true); fetchAnnouncements(); }}
                          style={{
                              ...navBtnBase,
                              background: 'linear-gradient(90deg, #d0daef 0%, #a2e7df 100%)',
                              color: '#2a4cef',
                              fontWeight: 900,
                              minWidth: '80px',
                              padding: '4px 10px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexDirection: 'row',
                          }}
                      >
                          <span style={{ fontSize: '24px', marginRight: '8px', transition: 'transform 0.22s' }}>📢</span>
                          <span style={{
                            fontSize: '18px',
                            fontWeight: 'bold',
                            background: 'linear-gradient(45deg, #ff4b4b 0%, #4169e1 100%)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            backgroundClip: 'text'
                          }}>通知公告</span>
                      </button>

                      {/* 每日签到按钮 */}
                      <button
                          onClick={handleCheckin}
                          disabled={currentUser?.lastCheckinDate === new Date().toISOString().slice(0, 10)}
                          style={{
                              ...navBtnBase,
                              background: 'linear-gradient(90deg, #ffd0d9 0%, #a2e7df 100%)',
                              color: '#2a4cef',
                              fontWeight: 900,
                              minWidth: '80px',
                              padding: '4px 10px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexDirection: 'row',
                              opacity: currentUser?.lastCheckinDate === new Date().toISOString().slice(0, 10) ? '0.6' : '1',
                              cursor: currentUser?.lastCheckinDate === new Date().toISOString().slice(0, 10) ? 'not-allowed' : 'pointer',
                          }}
                      >
                          <span style={{ fontSize: '24px', marginRight: '8px', transition: 'transform 0.22s' }}>📅</span>
                          <span style={{
                            fontSize: '18px',
                            fontWeight: 'bold',
                            background: 'linear-gradient(45deg, #ff4b4b 0%, #4169e1 100%)',
                            WebkitBackgroundClip: 'text',
                            WebkitTextFillColor: 'transparent',
                            backgroundClip: 'text'
                          }}>{currentUser?.lastCheckinDate === new Date().toISOString().slice(0, 10) ? '已签到' : '每日签到'}</span>
                      </button>
                    </>
                  )}
                </div>
            </div>
            <style>{`
                @keyframes dropdownFade {
                    from {
                        opacity: 0;
                        transform: translateY(-10px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
                
                .avatar-wrapper:hover {
                    background: rgba(0, 40, 120, 0.4) !important;
                    transform: translateY(-2px);
                    box-shadow: 0 4px 15px rgba(0, 194, 255, 0.2);
                }
                
                .dropdown-item i {
                    opacity: 0.8;
                }
                
                .dropdown::before {
                    content: '';
                    position: absolute;
                    top: -6px;
                    right: 20px;
                    width: 12px;
                    height: 12px;
                    background: rgba(16, 20, 34, 0.95);
                    transform: rotate(45deg);
                }

                .write {
                    position: relative;
                }

                .write::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(45deg, 
                        rgba(0, 255, 255, 0.1), 
                        rgba(255, 0, 255, 0.1)
                    );
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }

                .write::after {
                    content: '';
                    position: absolute;
                    top: -2px;
                    left: -2px;
                    right: -2px;
                    bottom: -2px;
                    background: linear-gradient(45deg, 
                        #00ffff, 
                        #ff00ff, 
                        #00ffff
                    );
                    border-radius: 22px;
                    z-index: -1;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }

                .write:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(0, 200, 220, 0.15);
                }

                .write:hover::before {
                    opacity: 1;
                }

                .write:hover::after {
                    opacity: 0.3;
                    animation: borderRotate 4s linear infinite;
                }

                @keyframes borderRotate {
                    0% {
                        transform: rotate(0deg);
                    }
                    100% {
                        transform: rotate(360deg);
                    }
                }

                .write:hover .link {
                    color: #ffffff;
                    text-shadow: 0 0 10px rgba(0, 200, 220, 0.6);
                }

                .write .fas {
                    transition: transform 0.3s ease;
                }

                .write:hover .fas {
                    transform: rotate(-15deg) scale(1.1);
                }

                .ranking-dropdown {
                    animation: dropdownFade 0.3s ease;
                }

                @keyframes sparkle {
                    0% {
                        transform: scale(1);
                        opacity: 1;
                    }
                    50% {
                        transform: scale(1.2);
                        opacity: 0.8;
                    }
                    100% {
                        transform: scale(1);
                        opacity: 1;
                    }
                }

                .links {
                    display: flex;
                    flex-wrap: wrap;
                    align-items: center;
                    gap: 0;
                }
                .links > * {
                    margin-left: 24px !important;
                    margin-bottom: 8px;
                }
                @media (max-width: 1200px) {
                    .links > * {
                        min-width: 90px;
                        font-size: 15px;
                        padding: 0 10px;
                    }
                }
                @media (max-width: 900px) {
                    .links {
                        flex-wrap: wrap;
                        justify-content: flex-start;
                    }
                    .links > * {
                        min-width: 70px;
                        font-size: 13px;
                        padding: 0 6px;
                    }
                }
                @media (max-width: 600px) {
                    .links {
                        flex-direction: column;
                        align-items: stretch;
                    }
                    .links > * {
                        width: 100%;
                        margin-left: 0 !important;
                        margin-bottom: 10px;
                    }
                }

                .write, .ranking-button, button[style*='navBtnBase'] {
                    box-shadow: 0 4px 24px 0 rgba(75, 108, 255, 0.13);
                    border: 1.5px solid rgba(255,255,255,0.18);
                    border-radius: 28px !important;
                    backdrop-filter: blur(8px);
                    transition: all 0.22s cubic-bezier(.4,2,.6,1);
                    position: relative;
                    overflow: hidden;
                }

                .write:hover, .ranking-button:hover, button[style*='navBtnBase']:hover {
                    filter: brightness(1.08) saturate(1.2);
                    box-shadow: 0 8px 32px 0 rgba(0, 234, 255, 0.22);
                    transform: translateY(-3px) scale(1.04);
                    z-index: 2;
                }

                .write:active, .ranking-button:active, button[style*='navBtnBase']:active {
                    transform: scale(0.97);
                    filter: brightness(0.98);
                }

                .write .fas, .ranking-button span:first-child, button[style*='navBtnBase'] span[style*='font-size: 26px'] {
                    transition: transform 0.22s;
                }

                .write:hover .fas, .ranking-button:hover span:first-child, button[style*='navBtnBase']:hover span[style*='font-size: 26px'] {
                    transform: rotate(-10deg) scale(1.13);
                }

                .write .link, .ranking-button span, button[style*='navBtnBase'] span {
                    font-family: 'PingFang SC', 'HarmonyOS Sans', 'Poppins', Arial, sans-serif;
                }

                .user-points {
                    position: relative;
                    font-weight: bold;
                    color: #ffd700;
                    margin-left: 8px;
                    font-size: 18px;
                }
                .points-badge {
                    position: absolute;
                    top: -18px;
                    right: -10px;
                    background: #fffae0;
                    color: #ff9800;
                    border-radius: 12px;
                    padding: 2px 8px;
                    font-size: 15px;
                    font-weight: bold;
                    opacity: 0;
                    transform: translateY(0);
                    transition: all 0.5s cubic-bezier(.4,2,.6,1);
                    pointer-events: none;
                }
                .points-badge.show {
                    opacity: 1;
                    transform: translateY(-20px) scale(1.2);
                }

                @keyframes checkmarkFade {
                    from {
                        opacity: 0;
                        transform: scale(0.5);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }
            `}</style>
            <AnnouncementModal
                visible={showAnnouncement}
                onClose={() => setShowAnnouncement(false)}
                announcements={announcements}
                currentUser={currentUser}
                onPublish={fetchAnnouncements}
            />
        </div>
    )
}

export default Navbar;
