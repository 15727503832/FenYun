const express = require('express');
const PostsModel = require("../mongo/models/postsModel");
const apiJSON = require("../utils/jsonCreator");
const UserModel = require("../mongo/models/userModel");
const router = express.Router();
const { checkTokenMiddleware } = require('../mongo/middlewares/checkTokenMiddleware');

let { successJSON, errorJSON, notAuthenticatedJSON } = apiJSON()

// 获取所有活动
router.get('/', function (req, res, next) {
    const { category, status, search, sort } = req.query;
    let query = {};
    
    // 按类别筛选
    if (category) {
        query.category = category;
    }

    // 按状态筛选
    if (status) {
        query.status = status;
    }

    // 搜索活动名称
    if (search) {
        query.title = new RegExp(search, 'i');
    }

    // 设置排序方式
    let sortOption = { startTime: 1 }; // 默认按活动开始时间排序
    if (sort === 'participants') {
        sortOption = { currentParticipants: -1 }; // 按参与人数降序排序
    }

    PostsModel.find(query)
        .sort(sortOption)
        .exec(function (err, activities) {
            if (err) {
                res.json(errorJSON('获取失败'));
            } else {
                res.json(successJSON('获取成功', activities));
            }
        });
});

// 获取单个活动
router.get('/:id', function (req, res, next) {
    PostsModel.findById(req.params.id, function (err, activity) {
        if (err) {
            res.json(errorJSON('获取失败'));
        } else {
            UserModel.findById(activity.uid, function (err, user) {
                if (err) {
                    res.json(errorJSON('获取失败'));
                } else {
                    res.json(successJSON('获取成功', { activity: activity, author: user }));
                }
            });
        }
    });
});

// 新增活动
router.post('/', checkTokenMiddleware, async function (req, res, next) {
    // 只有社团管理员才能发布活动
    const user = await UserModel.findById(req.user._id);
    if (!user || !user.isClubAdmin) {
        return res.json(errorJSON('只有社团管理员才能发布活动'));
    }
    // 验证必填字段
    const requiredFields = ['title', 'desc', 'category', 'img', 'points', 'location', 'startTime', 'endTime'];
    for (const field of requiredFields) {
        if (!req.body[field]) {
            return res.json(errorJSON(`${field} 不能为空`));
        }
    }

    PostsModel.create({
        uid: req.user._id,
        ...req.body,
        status: 'upcoming', // 新活动默认为未开始状态
        currentParticipants: 0 // 初始参与人数为0
    }, async function (err, data) {
        if (err) {
            return res.json(errorJSON('创建失败'));
        }
        // 发布活动成功后给用户加20分
        await UserModel.findByIdAndUpdate(req.user._id, { $inc: { points: 20 } });
        return res.json(successJSON('创建成功', data));
    });
});

// 更新活动
router.put('/:id', checkTokenMiddleware, async function (req, res, next) {
    try {
        const activity = await PostsModel.findById(req.params.id);
        if (!activity) {
            return res.json(errorJSON('活动不存在'));
        }
        const user = await UserModel.findById(req.user._id);
        // 允许作者本人、管理员、社团管理员编辑
        if (
            activity.uid.toString() !== req.user._id.toString() &&
            !user.isAdmin &&
            !user.isClubAdmin
        ) {
            return res.json(notAuthenticatedJSON('无权限修改此活动'));
        }
        // 更新活动信息
        PostsModel.findByIdAndUpdate(
            req.params.id,
            { $set: req.body },
            { new: true },
            function (err, updatedActivity) {
                if (err) {
                    console.error('更新活动失败:', err); // 添加错误日志
                    return res.json(errorJSON('更新失败', { error: err.message })); // 返回具体错误信息
                }
                return res.json(successJSON('更新成功', updatedActivity));
            }
        );
    } catch (err) {
        console.error('服务器错误:', err); // 添加错误日志
        return res.json(errorJSON('服务器错误', { error: err.message }));
    }
});

// 删除活动
router.delete('/:id', checkTokenMiddleware, function (req, res, next) {
    PostsModel.findById(req.params.id, function (err, activity) {
        if (err) {
            return res.json(errorJSON('活动不存在'));
        }
        
        // 检查是否是活动创建者
        if (activity.uid.toString() !== req.user._id.toString()) {
            return res.json(notAuthenticatedJSON('无权限删除此活动'));
        }
        
        PostsModel.findByIdAndDelete(req.params.id, function (err) {
            if (err) {
                return res.json(errorJSON('删除失败'));
            }
            return res.json(successJSON('删除成功'));
        });
    });
});

// 更新活动状态
router.patch('/:id/status', checkTokenMiddleware, function (req, res, next) {
    const { status } = req.body;
    if (!['upcoming', 'ongoing', 'completed'].includes(status)) {
        return res.json(errorJSON('无效的状态值'));
    }

    PostsModel.findByIdAndUpdate(
        req.params.id,
        { $set: { status } },
        { new: true },
        function (err, updatedActivity) {
            if (err) {
                return res.json(errorJSON('状态更新失败'));
            }
            return res.json(successJSON('状态更新成功', updatedActivity));
        }
    );
});

// 参与活动
router.post('/:id/participate', checkTokenMiddleware, function (req, res, next) {
    PostsModel.findById(req.params.id, function (err, activity) {
        if (err) {
            return res.json(errorJSON('活动不存在'));
        }
        
        // 检查活动状态
        if (activity.status !== 'upcoming') {
            return res.json(errorJSON('活动已开始或已结束'));
        }
        
        // 检查人数限制
        if (activity.maxParticipants > 0 && activity.currentParticipants >= activity.maxParticipants) {
            return res.json(errorJSON('活动人数已满'));
        }
        
        // 更新参与人数
        PostsModel.findByIdAndUpdate(
            req.params.id,
            { $inc: { currentParticipants: 1 } },
            { new: true },
            function (err, updatedActivity) {
                if (err) {
                    return res.json(errorJSON('参与失败'));
                }
                return res.json(successJSON('参与成功', updatedActivity));
            }
        );
    });
});

// 点赞活动
router.post('/:id/like', checkTokenMiddleware, async function (req, res, next) {
    try {
        const { id } = req.params;
        const userId = req.user._id;

        // 查找活动
        const activity = await PostsModel.findById(id);
        if (!activity) {
            return res.json(errorJSON('活动不存在'));
        }

        // 检查是否已经点赞
        if (activity.likedBy.includes(userId)) {
            return res.json(errorJSON('已经点赞过了'));
        }

        // 更新活动点赞信息
        const updatedActivity = await PostsModel.findByIdAndUpdate(
            id,
            {
                $inc: { likes: 1 },
                $push: { likedBy: userId }
            },
            { new: true }
        );

        // 给活动发布者加积分
        const activityCreator = await UserModel.findById(activity.uid);
        if (activityCreator) {
            await UserModel.findByIdAndUpdate(
                activity.uid,
                { $inc: { points: 5 } }  // 每获得一个点赞加5分
            );
        }

        res.json(successJSON('点赞成功', {
            likes: updatedActivity.likes,
            points: activityCreator ? activityCreator.points + 5 : 0
        }));
    } catch (err) {
        console.error('点赞失败:', err);
        res.json(errorJSON('点赞失败'));
    }
});

// 取消点赞
router.post('/:id/unlike', checkTokenMiddleware, async function (req, res, next) {
    try {
        const { id } = req.params;
        const userId = req.user._id;

        // 查找活动
        const activity = await PostsModel.findById(id);
        if (!activity) {
            return res.json(errorJSON('活动不存在'));
        }

        // 检查是否已经点赞
        if (!activity.likedBy.includes(userId)) {
            return res.json(errorJSON('还没有点赞'));
        }

        // 更新活动点赞信息
        const updatedActivity = await PostsModel.findByIdAndUpdate(
            id,
            {
                $inc: { likes: -1 },
                $pull: { likedBy: userId }
            },
            { new: true }
        );

        // 只减少活动发布者的receivedLikes，不扣积分
        const activityCreator = await UserModel.findById(activity.uid);
        if (activityCreator) {
            await UserModel.findByIdAndUpdate(
                activity.uid,
                { $inc: { receivedLikes: -1 } }
            );
        }

        res.json(successJSON('取消点赞成功', {
            likes: updatedActivity.likes,
            points: activityCreator ? activityCreator.points : 0
        }));
    } catch (err) {
        console.error('取消点赞失败:', err);
        res.json(errorJSON('取消点赞失败'));
    }
});

module.exports = router;
